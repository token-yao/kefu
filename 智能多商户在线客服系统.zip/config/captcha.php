<?php
/**
 * Created by PhpStorm.
 * User: 6666666
 * Email: 2097984975@qq.com
 * Date: 2019/5/22
 * Time: 9:48 PM
 */

// detail https://www.kancloud.cn/manual/thinkphp5_1/354122

return [

    'length' => 4,
    'useNoise' => false,
    'useCurve' => false,
    'codeSet' => '0123456789'
];