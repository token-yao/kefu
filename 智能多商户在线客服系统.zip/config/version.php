<?php
/**
 * Created by PhpStorm.
 * User: 6666666
 * Email: 2097984975@qq.com
 * Date: 2019/4/13
 * Time: 12:31 PM
 */
return [
    // 版本
    'version' => 'v2.1.14',
];