<?php
/**
 * Created by PhpStorm.
 * User: 6666666
 * Email: 2097984975@qq.com
 * Date: 2019/2/16
 * Time: 11:35 PM
 */
return [

    // 加密盐
    'salt' => '~NickBai!@#123',

    // 通信协议
    'protocol' => 'ws://',

    // socket server
    'socket' => 'cs.mingzhutianxia.com:2020',

    // 初始化问候语
    'hello_word' => '您好，xiaotian客服为您服务',

    // 当前系统域名
    'domain' => 'http://cs.mingzhutianxia.com',

    // 聊天信息一次展示多少条
    'log_page' => 10,

    // 是否开启商户注册
    'reg_flag' => true,

    // api接口
    'api_url' => 'http://cs.mingzhutianxia.com/index/test/receive'
];