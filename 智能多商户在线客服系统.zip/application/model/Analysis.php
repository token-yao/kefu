<?php
/**
 * Created by PhpStorm.
 * User: 6666666
 * Date: 2019/2/20
 * Time: 14:15
 */
namespace app\model;

use think\Model;

class Analysis extends Model
{
    public function updateTotalData()
    {

    }
}